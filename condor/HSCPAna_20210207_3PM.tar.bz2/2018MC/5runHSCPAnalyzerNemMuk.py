# Analyze pixel trees with HSCP Analyzer
# Author: Tamas Almos Vami (JHU)
# 

import os, re, sys, glob, socket, subprocess, ROOT
import FWCore.ParameterSet.Config as cms
from Configuration.Eras.Era_Run2_2018_cff import Run2_2018

process = cms.Process('HSCPAnalyzer',Run2_2018)

process.load('Configuration.StandardSequences.GeometryRecoDB_cff')
process.load('Configuration.StandardSequences.MagneticField_cff')
process.load('Configuration.StandardSequences.FrontierConditions_GlobalTag_cff')
process.load('CalibTracker.SiPixelESProducers.SiPixelTemplateDBObjectESProducer_cfi')
process.load('CalibTracker.SiPixelESProducers.SiPixel2DTemplateDBObjectESProducer_cfi')

process.maxEvents = cms.untracked.PSet(
    input = cms.untracked.int32(1)
)

process.MessageLogger = cms.Service("MessageLogger",
    debugModules = cms.untracked.vstring('HSCPAnalyzer'),
    destinations = cms.untracked.vstring('cout'),
    cout = cms.untracked.PSet(
        threshold = cms.untracked.string('ERROR')
    )
)
    
import FWCore.ParameterSet.VarParsing as opts
opt = opts.VarParsing ('analysis')
opt.register('runNumber',           1,
	     opts.VarParsing.multiplicity.singleton, opts.VarParsing.varType.int,
	     'Using a predetermined run number')

opt.register('fileName',          '',
	     opts.VarParsing.multiplicity.singleton, opts.VarParsing.varType.string,
	     'File to be run on')

opt.parseArguments()
runNumber = opt.runNumber
FileName = opt.fileName

#root://cms-xrd-global.cern.ch//store/user/tvami//PixelTrees//SingleMuon//crab_ALCARECO_2018A_PixelTrees_v1/200604_040318/0000/PixelTree_69.root

#inName = cms.untracked.string(FileName)
#fin = ROOT.TFile.Open(inName)
# for i in range(0, fin.GetListOfKeys().GetEntries()):
    #obj = f.Get("run")
#tree = fin.Get("pixelTree")
#histo = tree.GetLeaf("run")
#runnie = histo.GetValue()
#runnie = histo.GetMean() # GetValue
#print(runnie)


process.source = cms.Source("EmptySource",
    firstRun = cms.untracked.uint32(runNumber),
)

from Configuration.AlCa.GlobalTag import GlobalTag
if runNumber >1:
    process.GlobalTag = GlobalTag(process.GlobalTag, '106X_dataRun2_v27', '')
else:
    #process.GlobalTag = GlobalTag(process.GlobalTag, '106X_mc2017_realistic_v7', '')
    process.GlobalTag = GlobalTag(process.GlobalTag, '106X_upgrade2018_realistic_v11', '')

process.TFileService = cms.Service('TFileService',
                                 fileName = cms.string('HSCPAna_Run'+str(runNumber)+'.root'),
                                 )

FileName = cms.untracked.string("root://cms-xrd-global.cern.ch//eos/cms/store/caf/user/tvami/HSCP/IncStat/MC2018_HSCP_M1800_PixelTrees.root")

process.analysis = cms.EDAnalyzer("HSCPStudy",
    Verbosity = cms.untracked.int32(0),
    rootFileName = FileName
    #rootFileName = cms.untracked.string("root://cms-xrd-global.cern.ch//eos/cms/store/caf/user/tvami/HSCP/IncStat/MC2018_HSCP_M1800_PixelTrees.root")
)

process.p = cms.Path(process.analysis)

