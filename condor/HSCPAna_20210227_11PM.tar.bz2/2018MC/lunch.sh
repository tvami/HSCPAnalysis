cd ..
scram b -j 
cd -
#cmsRun 5runHSCPAnalyzer.py runNumber=315690
#cmsRun 5runHSCPAnalyzer.py runNumber=324293
#cmsRun 5runHSCPAnalyzer.py runNumber=1
cmsRun 5runHSCPAnalyzer.py fileName="root://cms-xrd-global.cern.ch//eos/cms/store/caf/user/tvami/HSCP/IncStat/MC2018_HSCP_M1800_PixelTrees.root"

