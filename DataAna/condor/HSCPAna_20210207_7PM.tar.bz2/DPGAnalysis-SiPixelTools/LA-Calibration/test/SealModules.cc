#include "FWCore/PluginManager/interface/ModuleDef.h"
#include "FWCore/Framework/interface/MakerMacros.h"
#include "../test/SiPixelLorentzAngleReader.h"


DEFINE_FWK_MODULE(SiPixelLorentzAngleReader);
