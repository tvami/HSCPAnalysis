cd .. 
scram b -j 
cd -
 cmsRun 5runHSCPAnalyzer.py runNumber=315690
