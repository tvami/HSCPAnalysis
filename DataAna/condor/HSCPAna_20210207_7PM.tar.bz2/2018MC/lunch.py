import os
import ROOT 


f = ROOT.TFile.Open("root://cms-xrd-global.cern.ch//eos/cms/store/caf/user/tvami/HSCP/IncStat/MC2018_HSCP_M1800_PixelTrees.root")

histo = f.Get("pixelTree/run")
runNumber = histo.GetMean()
print(runNumber)

f.Close()


#os.system('cmsRun 5runHSCPAnalyzer.py fileName="root://cms-xrd-global.cern.ch//eos/cms/store/caf/user/tvami/HSCP/IncStat/MC2018_HSCP_M1800_PixelTrees.root" runNumber='+str(runnie)+'')

